﻿using MvcCoreLeaveApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.Contracts
{
    public interface ILeaveTypeRepository : IRepositoryBase<LeaveTypes>
    {
        Task<ICollection<LeaveTypes>> GetEmployeesByLeaveType(int id);
    }
}
