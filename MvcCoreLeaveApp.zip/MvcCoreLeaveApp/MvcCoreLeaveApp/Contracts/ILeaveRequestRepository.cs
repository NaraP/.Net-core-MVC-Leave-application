﻿using MvcCoreLeaveApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.Contracts
{
    public interface ILeaveRequestRepository : IRepositoryBase<LeaveRequests>
    {
        Task<ICollection<LeaveRequests>> GetLeaveRequestsByEmployee();

        LeaveRequests GetLeaveRequestById(int RequestingEmployeeId, int leaveTypeId);
    }
}
