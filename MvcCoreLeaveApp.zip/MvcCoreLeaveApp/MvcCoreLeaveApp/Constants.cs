﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp
{
    public static class Constants
    {
        public static string leaveApproved = "Your leave request has been approved.";
        public static string leaveRejected = " Your leave request has been rejected.";
        public static string leaveRequest = "A new leave request for approve or reject.";
       
    }
}
