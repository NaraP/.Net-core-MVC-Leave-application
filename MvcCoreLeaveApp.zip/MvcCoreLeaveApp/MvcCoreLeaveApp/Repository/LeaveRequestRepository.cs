﻿using Microsoft.EntityFrameworkCore;
using MvcCoreLeaveApp.Contracts;
using MvcCoreLeaveApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.Repository
{
    public class LeaveRequestRepository : ILeaveRequestRepository
    {
        private readonly LeaveContext _db;

        public LeaveRequestRepository(LeaveContext db)
        {
            _db = db;
        }

        public LeaveRequests GetLeaveRequestById(int RequestingEmployeeId, int leaveTypeId)
        {
            var result = _db.LeaveRequests.Where(x => x.RequestingEmployeeId == RequestingEmployeeId.ToString() && x.LeaveTypeId == leaveTypeId && x.DateRequested != null).FirstOrDefault();

            return result;
        }
        public async Task<bool> Create(LeaveRequests entity)
        {
            await _db.LeaveRequests.AddAsync(entity);
            return await Save();
        }

        public async Task<bool> Delete(LeaveRequests entity)
        {
            _db.LeaveRequests.Remove(entity);
            return await Save();
        }

        public async Task<ICollection<LeaveRequests>> FindAll()
        {
            var leaveRequests = await _db.LeaveRequests
                .ToListAsync();
            return leaveRequests;
        }

        public async Task<LeaveRequests> FindById(int id)
        {
            var leaveRequest = await _db.LeaveRequests
                .Where(q => q.Id == id && q.Approved == null).FirstOrDefaultAsync();
            return leaveRequest;
        }

        public async Task<ICollection<LeaveRequests>> GetLeaveRequestsByEmployee()
        {
            var leaveRequests = await FindAll();
            //return leaveRequests.Where(q => q.RequestingEmployeeId == employeeid)
            //.ToList();

            return leaveRequests.ToList();
        }

        public async Task<bool> isExists(int id)
        {
            var exists = await _db.LeaveRequests.AnyAsync(q => q.Id == id);
            return exists;
        }

        public async Task<bool> Save()
        {
            var changes = await _db.SaveChangesAsync();
            return changes > 0;
        }

        public async Task<bool> Update(LeaveRequests entity)
        {
            _db.LeaveRequests.Update(entity);
            return await Save();
        }
    }
}
