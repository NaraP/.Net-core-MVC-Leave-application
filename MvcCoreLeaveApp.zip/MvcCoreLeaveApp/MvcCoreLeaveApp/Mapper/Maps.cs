﻿using AutoMapper;
using MvcCoreLeaveApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.Mapper
{
    public class Maps : Profile
    {
        public Maps()
        {
            CreateMap<LeaveTypes, LeaveTypeVM>().ReverseMap();
            CreateMap<LeaveRequests, LeaveRequestVM>().ReverseMap();
          //  CreateMap<LeaveAllocation, LeaveAllocationVM>().ReverseMap();
           // CreateMap<LeaveAllocation, EditLeaveAllocationVM>().ReverseMap();
           // CreateMap<Userdetails, EmployeeVM>().ReverseMap();
        }
    }
}
