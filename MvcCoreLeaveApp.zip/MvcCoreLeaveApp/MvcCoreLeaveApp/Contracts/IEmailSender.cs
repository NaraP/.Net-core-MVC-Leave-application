﻿using MvcCoreLeaveApp.EmailHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.Contracts
{
    public interface IEmailSender
    {
        //void SendEmail(EmailMessage message);
       string SendMail(string toList, string from, string ccList, string subject, string body);
    }
}
