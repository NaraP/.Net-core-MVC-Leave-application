﻿using System;
using System.Collections.Generic;

namespace MvcCoreLeaveApp.Models
{
    public partial class LeaveTypes
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DateCreated { get; set; }
        public int DefaultDays { get; set; }
    }
}
