﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MvcCoreLeaveApp.Contracts;
using MvcCoreLeaveApp.EmailHelper;
using MvcCoreLeaveApp.Models;

namespace MvcCoreLeaveApp.Controllers
{
    public class LeaveRequestController : Controller
    {
        private readonly ILeaveRequestRepository _leaveRequestRepo;
        private readonly ILeaveTypeRepository _leaveTypeRepo;
        private readonly IMapper _mapper;

        private IHostingEnvironment _env;

        private readonly IEmailSender _emailSender;

        private readonly IUserRepository _userRepository;

        private readonly IHttpContextAccessor _contextAccessor;

        public LeaveRequestController(
            ILeaveRequestRepository leaveRequestRepo, 
            ILeaveTypeRepository leaveTypeRepo,
            IMapper mapper, IHttpContextAccessor contextAccessor, IUserRepository userRepository, IEmailSender emailSender, IHostingEnvironment env
        )
        {
            _leaveRequestRepo = leaveRequestRepo;
            _leaveTypeRepo = leaveTypeRepo;
            _mapper = mapper;
            _contextAccessor = contextAccessor;
            _userRepository = userRepository;

            _env = env;
            _emailSender = emailSender;
        }

        // [Authorize(Roles = "Administrator")]
        // GET: LeaveRequest
        public async Task<ActionResult> Index()
        {
            AdminLeaveRequestViewVM model = new AdminLeaveRequestViewVM();
            List<LeaveRequestVM> leaveRequestVMs = new List<LeaveRequestVM>();
            LeaveRequestVM leaveRequestVM = new LeaveRequestVM();

            try
            {
                var leaveRequests = await _leaveRequestRepo.FindAll();

                if (leaveRequests.Count() > 0 && leaveRequests != null)
                {
                    var leaveRequstsModel = _mapper.Map<List<LeaveRequestVM>>(leaveRequests);

                    var LeaveTypes = await _leaveTypeRepo.FindAll();

                    model.TotalRequests = leaveRequstsModel.Count;
                    model.ApprovedRequests = leaveRequstsModel.Count(q => q.Approved == true);
                    model.PendingRequests = leaveRequstsModel.Count(q => q.Approved == null);
                    model.RejectedRequests = leaveRequstsModel.Count(q => q.Approved == false);

                    foreach (var item in leaveRequstsModel)
                    {
                        var UserDetails = _userRepository.GetUserById(Convert.ToInt32(item.RequestingEmployeeId));
                        leaveRequestVM = new LeaveRequestVM();

                        var TypeName = LeaveTypes.Where(x => x.Id == item.LeaveTypeId).FirstOrDefault();

                        leaveRequestVM = new LeaveRequestVM();
                        leaveRequestVM.Id = item.Id;
                        leaveRequestVM.StartDate = item.StartDate;
                        leaveRequestVM.EndDate = item.EndDate;
                        leaveRequestVM.StartDate = item.StartDate;
                        leaveRequestVM.LeaveType.Name = TypeName.Name;
                        leaveRequestVM.RequestingEmployee.Name = UserDetails.Name;
                        leaveRequestVM.DateRequested = item.DateRequested;
                        leaveRequestVM.Cancelled = item.Cancelled;
                        leaveRequestVM.Approved = item.Approved;
                        leaveRequestVM.Cancelled = item.Cancelled;

                        leaveRequestVMs.Add(leaveRequestVM);
                    }

                    model.LeaveRequests = leaveRequestVMs;
                }
            }
            catch(Exception ex)
            {
                //we can log the exeception
            }
            return View(model);
        }

        public async Task<ActionResult> MyLeave()
        {
            EmployeeLeaveRequestViewVM model = new EmployeeLeaveRequestViewVM();

            List<LeaveRequestVM> LeaveRequests = new List<LeaveRequestVM>();

            LeaveRequestVM leaveRequestVM = null;

            try
            {
                var employeeRequests = await _leaveRequestRepo.GetLeaveRequestsByEmployee();

                if (employeeRequests.Count > 0 && employeeRequests != null)
                {
                    var LeaveTypes = await _leaveTypeRepo.FindAll();

                    var employeeRequestsModel = _mapper.Map<List<LeaveRequestVM>>(employeeRequests);

                    foreach (var item in employeeRequestsModel)
                    {
                        var TypeName = LeaveTypes.Where(x => x.Id == item.LeaveTypeId).FirstOrDefault();

                        leaveRequestVM = new LeaveRequestVM();
                        leaveRequestVM.StartDate = item.StartDate;
                        leaveRequestVM.EndDate = item.EndDate;
                        leaveRequestVM.StartDate = item.StartDate;
                        leaveRequestVM.LeaveType.Name = TypeName.Name;
                        leaveRequestVM.DateRequested = item.DateRequested;
                        leaveRequestVM.Cancelled = item.Cancelled;
                        leaveRequestVM.Approved = item.Approved;
                        leaveRequestVM.Cancelled = item.Cancelled;

                        LeaveRequests.Add(leaveRequestVM);
                    }

                    model.LeaveRequests = LeaveRequests;
                }
            }
            catch(Exception ex)
            { 
            }

            return View(model);
        }

        // GET: LeaveRequest/Details/5
        public async Task<ActionResult> Details(int id)
        {
            var model = default(LeaveRequestVM);

            if (id != 0)
            {
                var leaveRequest = await _leaveRequestRepo.FindById(id);

                if (leaveRequest != null)
                {
                    var UserDetails = _userRepository.GetUserById(Convert.ToInt32(leaveRequest.RequestingEmployeeId));

                    ViewBag.Name = UserDetails.Name;

                    model = _mapper.Map<LeaveRequestVM>(leaveRequest);
                }
            }

            if (model == null)
            {
                return RedirectToAction(nameof(Details));
            }
            else
            {
                return View(model);
            }
        }

        public async Task<ActionResult> ApproveRequest(int id)
        {
            try
            {
                if (id != 0)
                {
                    var leaveRequest = await _leaveRequestRepo.FindById(id);
                    var employeeid = leaveRequest.RequestingEmployeeId;
                    var leaveTypeId = leaveRequest.LeaveTypeId;
                    int daysRequested = (int)(leaveRequest.EndDate - leaveRequest.StartDate).TotalDays;

                    leaveRequest.Approved = true;
                    leaveRequest.DateActioned = DateTime.Now;

                    await _leaveRequestRepo.Update(leaveRequest);

                    var UserDetails = _userRepository.GetUserById(Convert.ToInt32(employeeid));

                    string EmailBody = CommonHelper.PopulateBody(UserDetails.Name, "Your leave request has been approved.", string.Empty);

                    EmailMessage emailMessage = new EmailMessage("Leave request", "pnara527@gmail.com", EmailBody, "pnara527@gmail.com", string.Empty, "", null);

                    _emailSender.SendMail("pnara527@gmail.com", "pnara527@gmail.com", null, Constants.leaveApproved, EmailBody);
                }
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                return RedirectToAction(nameof(Index));
            }
        }

        public async Task<ActionResult> RejectRequest(int id)
        {
            try
            {
                if (id != 0)
                {
                    var leaveRequest = await _leaveRequestRepo.FindById(id);
                    leaveRequest.Approved = false;
                    leaveRequest.DateActioned = DateTime.Now;

                    await _leaveRequestRepo.Update(leaveRequest);

                    var UserDetails = _userRepository.GetUserById(Convert.ToInt32(leaveRequest.RequestingEmployeeId));

                    string EmailBody = CommonHelper.PopulateBody(UserDetails.Name, "Your leave request has been rejected.", string.Empty);

                    EmailMessage emailMessage = new EmailMessage("Leave request", "pnara527@gmail.com", EmailBody, "pnara527@gmail.com", string.Empty, "", null);

                    _emailSender.SendMail("pnara527@gmail.com", "pnara527@gmail.com", null, Constants.leaveRejected, EmailBody);
                }
                return RedirectToAction(nameof(Index));

            }
            catch (Exception ex)
            {
                return RedirectToAction(nameof(Index));
            }
        }

        // GET: LeaveRequest/Create
        public async Task<ActionResult> Create()
        {
            var leaveTypes = await _leaveTypeRepo.FindAll();
            var leaveTypeItems = leaveTypes.Select(q => new SelectListItem
            {
                Text = q.Name,
                Value = q.Id.ToString()
            });
            var model = new CreateLeaveRequestVM
            {
                LeaveTypes = leaveTypeItems
            };
            return View(model);
        }

        // POST: LeaveRequest/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(CreateLeaveRequestVM model)
        {
            try
            {
                var userEmail = HttpContext.Session.GetString("userId");
                var UserDetails = _userRepository.GetUserByEmailId(userEmail);

                var startDate = Convert.ToDateTime(model.StartDate);
                var endDate = Convert.ToDateTime(model.EndDate);
                var leaveTypes = await _leaveTypeRepo.FindAll();
                int daysRequested = (int)(endDate - startDate).TotalDays;
                var leaveTypeItems = leaveTypes.Select(q => new SelectListItem
                {
                    Text = q.Name,
                    Value = q.Id.ToString()
                });
                model.LeaveTypes = leaveTypeItems;

                if (DateTime.Compare(startDate, endDate) > 1)
                {
                    ModelState.AddModelError("", "Start Date cannot be further in the future than the End Date");
                }
                //if (daysRequested > UserDetail.Result.NumberOfDays)
                //{
                //    ModelState.AddModelError("", "You Do Not Sufficient Days For This Request");
                //}
                if (!ModelState.IsValid)
                {
                    return View(model);
                }

                var leaveRequestModel = new LeaveRequestVM
                {
                    RequestingEmployeeId = Convert.ToString(UserDetails.Id),
                    StartDate = startDate,
                    EndDate = endDate,
                    Approved = null,
                    DateRequested = DateTime.Now,
                    DateActioned = DateTime.Now,
                    LeaveTypeId = model.LeaveTypeId,
                    RequestComments = model.RequestComments
                };

                var currenturl = _contextAccessor.HttpContext.Request.Host.Value;

                var leaveRequest = _mapper.Map<LeaveRequests>(leaveRequestModel);
                var isSuccess = await _leaveRequestRepo.Create(leaveRequest);

                var UserDetail = _leaveRequestRepo.GetLeaveRequestById(UserDetails.Id, model.LeaveTypeId);

                int requestId = Convert.ToInt32(leaveRequest.Id);

                string activationUrl = currenturl + "/LeaveRequest/Details/" + requestId;

                string EmailBody = CommonHelper.PopulateBody(UserDetails.Name, Constants.leaveRequest, activationUrl);

                EmailMessage emailMessage = new EmailMessage("Leave request", "pnara527@gmail.com", EmailBody,"pnara527@gmail.com", string.Empty, "",null);

                _emailSender.SendMail("pnara527@gmail.com","pnara527@gmail.com",null, Constants.leaveRequest, EmailBody);

                if (!isSuccess)
                {
                    ModelState.AddModelError("", "Something went wrong with submitting your record");
                    return View(model);
                }

                return RedirectToAction("MyLeave");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Something went wrong");
                return View(model);
            }
        }

        public async Task<ActionResult> CancelRequest(int id)
        {
            var leaveRequest = await _leaveRequestRepo.FindById(id);
            leaveRequest.Cancelled = true;
            await _leaveRequestRepo.Update(leaveRequest);
            return RedirectToAction("MyLeave");
        }

        // GET: LeaveRequest/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: LeaveRequest/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: LeaveRequest/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: LeaveRequest/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}