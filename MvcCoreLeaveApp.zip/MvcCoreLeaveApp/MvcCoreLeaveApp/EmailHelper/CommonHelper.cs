﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.EmailHelper
{
    public class CommonHelper
    {
        public static string PopulateBody(string userName, string title, string url)
        {
            string body = string.Empty;

            var emailtemplate = @"C:\\Users\\abb-rd\\source\repos\\TestApp\\MvcCoreLeaveApp\\MvcCoreLeaveApp\\EmailTemplate\\EmailTemplate.html";

            using (var reader = File.OpenText(emailtemplate.ToString()))
            {
                body = reader.ReadToEnd();
            }

            body = body.Replace("{UserName}", userName);
            body = body.Replace("{Title}", title);
            body = body.Replace("{Url}", url);
            return body;
        }
    }
}
