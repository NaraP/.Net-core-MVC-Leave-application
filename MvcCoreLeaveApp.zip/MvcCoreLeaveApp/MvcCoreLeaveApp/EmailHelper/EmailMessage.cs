﻿using MimeKit;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.EmailHelper
{
    public sealed class EmailMessage
    {
        private readonly IReadOnlyList<string> to;
        private readonly IReadOnlyList<string> cc;
        private readonly IReadOnlyList<string> bcc;
        private readonly List<string> attachments;

        public EmailMessage(string subject, string from, string body, string to,
            string cc, string bcc, List<string> attachments)
        {
            if (string.IsNullOrEmpty(subject))
                throw new ArgumentException("Subject must be set");

            if (string.IsNullOrEmpty(from))
                throw new ArgumentException("From must be set");

            if (string.IsNullOrEmpty(body))
                throw new ArgumentException("Body must be set");

            if (string.IsNullOrEmpty(to))
                throw new ArgumentException("At least one To must be set");

            this.Subject = subject;
            this.From = from;
            this.Body = body;
            this.To = to;
            this.CC = cc;
            this.BCC = bcc;
            this.attachments = attachments;
        }

        public string Subject { get; }
        public string From { get; }
        public string Body { get; }
        public string To { get; }
        public string CC { get; }
        public string BCC { get; }
        public string Attachments;

       
    }
}
