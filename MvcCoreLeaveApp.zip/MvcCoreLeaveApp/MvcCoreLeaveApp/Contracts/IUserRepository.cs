﻿using MvcCoreLeaveApp.Dtos;
using MvcCoreLeaveApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.Contracts
{
    public interface IUserRepository
    {
        Task<Userdetails> UserLogin(LoginViewModel model);

         Userdetails GetUserById(int id);

        Userdetails  GetUserByEmailId(string emailId);

        Task<int> Register(RegistrationViewModel model);

        Userdetails GetManagerData(bool isManager);
    }
}
