﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MvcCoreLeaveApp.Contracts;
using MvcCoreLeaveApp.Dtos;
using MvcCoreLeaveApp.Models;

namespace MvcCoreLeaveApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserRepository _context;

        public AccountController(IUserRepository context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userdetails = await  _context.UserLogin(model);

                if (userdetails == null)
                {
                    ModelState.AddModelError("Password", "Invalid login attempt.");
                    return View("Index");
                }
                HttpContext.Session.SetString("userId", userdetails.Email);
            }
            else
            {
                return View("Index");
            }
            return RedirectToAction("Create", "LeaveRequest");
        }
        [HttpPost]
        public async Task<ActionResult> Register(RegistrationViewModel model)
        {

            try
            {
                if (ModelState.IsValid)
                {
                   await _context.Register(model);
                }
                else
                {
                    return View("Registration");
                }
            }
            catch(Exception ex)
            {
            }
            return RedirectToAction("Index", "Account");
        }
        // registration Page load
        public IActionResult Registration()
        {
            ViewData["Message"] = "Registration Page";

            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View("Index");
        }
        public void ValidationMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }

        }
    }
}