﻿using Microsoft.EntityFrameworkCore;
using MvcCoreLeaveApp.Contracts;
using MvcCoreLeaveApp.Dtos;
using MvcCoreLeaveApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreLeaveApp.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly LeaveContext _context;

        public UserRepository(LeaveContext context)
        {
            _context = context;
        }

        public Userdetails GetUserById(int id)
        {
            return  _context.Userdetails.Where(x => x.Id.Equals(id)).FirstOrDefault();
        }

        public Userdetails GetUserByEmailId(string emailId)
        {
            return _context.Userdetails.Where(x => x.Email.Equals(emailId)).FirstOrDefault();
        }

        //public async Task<Userdetails> GetUserById(int id)
        //{
        //    return await _context.Userdetails.Where(x => x.Id.Equals(id)).FirstOrDefaultAsync();
        //}

        public async Task<int>  Register(RegistrationViewModel model)
        {
            Userdetails user = new Userdetails
            {
                Name = model.Name,
                Email = model.Email,
                Password = model.Password,
                Mobile = model.Mobile,
                IsManager = Convert.ToBoolean(model.IsManager)
            };
            _context.Add(user);
            int result =  await _context.SaveChangesAsync();
            return result;
        }

      public async Task<Userdetails>  UserLogin(LoginViewModel model)
        {
            return  await _context.Userdetails
                            .Where(m => m.Email == model.Email && m.Password == model.Password).FirstOrDefaultAsync();
        }
    }
}
